module snakedemo.snakedemo {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;


    opens snakedemo.snakedemo to javafx.fxml;
    exports snakedemo.snakedemo;
}