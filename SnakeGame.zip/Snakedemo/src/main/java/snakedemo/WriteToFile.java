package snakedemo;

import java.io.FileWriter;
import java.io.IOException;

public class WriteToFile {
        public static void writeFile(int a) {
            try {
                FileWriter myWriter = new FileWriter("highscore.txt");
                myWriter.write(String.valueOf(a));
                myWriter.close();
                System.out.println("Successfully stored new high score : " + a);
            } catch (IOException e) {
                System.out.println("An error occurred.");
                e.printStackTrace();
            }
        }
    }

