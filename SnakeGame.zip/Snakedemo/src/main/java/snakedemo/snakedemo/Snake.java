package snakedemo.snakedemo;

public class Snake {
    static int length = 4;
    public static int foodEaten;

    }
